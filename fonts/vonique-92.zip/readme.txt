OTF and TTF: Vonique 92 (Regular, Bold, Light, Italic, Light Italic, Bold Italic)
Dennis Ludlow 2015 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Bonjour font fans! We stamp our passports once more and hit the streets of Paris for another version of Vonique 64. Within a few short months it replaced "Grinched" as Sharkshock's most popular download. This urban, yet elegant display font has been revamped with redesigned lowercase 
companions to compliment the existing set. Artistic alternates were added for several characters along with 2 stylistic sets. As is the case with display fonts, this one is not meant to be used in body text but to serve as an ornamental solution for logos, titles and more. More emphasis was put on 
bringing out the wonderful French curves in Vonique over and over. Upper and lowercase letters were not designed to coexist, however certain combinations will produce striking results. Clients who purchased a commercial license for Vonique 64 will be able to upgrade and also have access
to all 6 versions.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags:italic, New York, Paris, France, London, UK, England, chic, stylish, urban, bold, title, display, font, typeface, publishing, logo, title, book, cover, magazine, company, street, subway, luxury, elegant, style, edge, NY, brand, branding, fancy
